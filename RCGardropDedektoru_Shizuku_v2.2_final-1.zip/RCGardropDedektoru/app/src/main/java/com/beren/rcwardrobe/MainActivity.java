package com.beren.rcwardrobe;

import android.app.Activity;
import android.content.ComponentName;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.IBinder;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import rikka.shizuku.Shizuku;

public class MainActivity extends Activity {
    private static final int REQ = 1001;
    private static final String RC_PACKAGE = "com.yourstoryinteractive.sails.pirate.adventure";
    private static final String SERVICE = "com.beren.rcwardrobe.service.FileScanService";

    private TextView status, result;
    private Button permissionButton, scanButton;
    private Shizuku.UserServiceConnection connection;
    private IFileScanService service;
    private Shizuku.UserServiceArgs serviceArgs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        status = findViewById(R.id.status);
        result = findViewById(R.id.result);
        permissionButton = findViewById(R.id.permissionButton);
        scanButton = findViewById(R.id.scanButton);
        result.setMovementMethod(new ScrollingMovementMethod());

        permissionButton.setOnClickListener(v -> requestShizuku());
        scanButton.setOnClickListener(v -> startScan());

        Shizuku.addBinderReceivedListenerSticky(() -> runOnUiThread(this::refresh));
        Shizuku.addBinderDeadListener(() -> runOnUiThread(() -> {
            status.setText("❌ Shizuku bağlantısı koptu.");
            scanButton.setEnabled(false);
        }));
        refresh();
    }

    private void refresh() {
        try {
            if (!Shizuku.pingBinder()) {
                status.setText("❌ Shizuku çalışmıyor.\nÖnce Shizuku'yu başlat.");
                scanButton.setEnabled(false);
                return;
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                status.setText("🟡 Shizuku çalışıyor.\nAşağıdaki düğmeden bu uygulamaya izin ver.");
                scanButton.setEnabled(false);
                return;
            }
            status.setText("🟢 Shizuku hazır.\nRomance Club /Android/data içindeki veriler taranabilir.");
            scanButton.setEnabled(true);
        } catch (Throwable t) {
            status.setText("⚠️ Shizuku kontrolünde hata:\n" + t);
            scanButton.setEnabled(false);
        }
    }

    private void requestShizuku() {
        try {
            if (!Shizuku.pingBinder()) {
                Toast.makeText(this, "Önce Shizuku'yu başlat.", Toast.LENGTH_LONG).show();
                return;
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(REQ);
            } else refresh();
        } catch (Throwable t) {
            result.setText("Shizuku izin hatası:\n" + t);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        refresh();
    }

    private void startScan() {
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
            requestShizuku();
            return;
        }

        final String root = "/storage/emulated/0/Android/data/" + RC_PACKAGE;
        result.setText("🔎 Romance Club verileri taranıyor...\n\nNormal verilerin yanında UnityFS oyun paketleri de çözümlenip taranacak.\nBu işlem dosya sayısına göre biraz sürebilir.\nTelefonu kapatma veya uygulamayı kapatma.");
        scanButton.setEnabled(false);
        permissionButton.setEnabled(false);

        connection = new Shizuku.UserServiceConnection() {
            @Override public void onServiceConnected(ComponentName name, IBinder binder) {
                service = IFileScanService.Stub.asInterface(binder);
                new Thread(() -> {
                    try {
                        String raw = service.scan(root);
                        runOnUiThread(() -> showResult(raw));
                    } catch (Throwable t) {
                        runOnUiThread(() -> showResult("HATA|" + t));
                    }
                }, "rc-scan").start();
            }
            @Override public void onServiceDisconnected(ComponentName name) {
                service = null;
            }
        };

        serviceArgs = new Shizuku.UserServiceArgs(
                new ComponentName(getPackageName(), SERVICE))
                .daemon(false)
                .debuggable(false)
                .processNameSuffix("scan")
                .tag("rc-wardrobe-scanner")
                .version(22);

        try {
            Shizuku.bindUserService(serviceArgs, connection);
        } catch (Throwable t) {
            showResult("SHIZUKU_USER_SERVICE_HATASI|" + t);
            scanButton.setEnabled(true);
            permissionButton.setEnabled(true);
        }
    }

    private void showResult(String raw) {
        scanButton.setEnabled(true);
        permissionButton.setEnabled(true);
        if (raw == null) {
            result.setText("Boş sonuç.");
            return;
        }
        if (raw.startsWith("ROOT_NOT_FOUND|")) {
            result.setText("❌ Romance Club dosya klasörü bulunamadı.\n\n" + raw.substring(15));
            return;
        }
        if (raw.startsWith("HATA|") || raw.startsWith("SHIZUKU_USER_SERVICE_HATASI|")) {
            result.setText("❌ Tarama hatası:\n" + raw);
            return;
        }

        Map<String,String> h = new LinkedHashMap<>();
        ArrayList<String> fileLines = new ArrayList<>();
        ArrayList<String> matchLines = new ArrayList<>();
        ArrayList<String> pairLines = new ArrayList<>();
        ArrayList<String> evidenceSummaryLines = new ArrayList<>();
        for (String line : raw.split("\\n")) {
            if (line.startsWith("FILE|")) fileLines.add(line);
            else if (line.startsWith("CATALOG_MATCH_ITEM|")) matchLines.add(line.substring("CATALOG_MATCH_ITEM|".length()));
            else if (line.startsWith("ACCOUNT_PAIR_ITEM|")) pairLines.add(line.substring("ACCOUNT_PAIR_ITEM|".length()));
            else if (line.startsWith("EVIDENCE_SUMMARY_ITEM|")) evidenceSummaryLines.add(line.substring("EVIDENCE_SUMMARY_ITEM|".length()));
            else {
                int p = line.indexOf('|');
                if (p > 0) h.put(line.substring(0,p), line.substring(p+1));
            }
        }

        StringBuilder b = new StringBuilder();
        b.append("✅ Tarama tamamlandı\n\n");
        b.append("Dosya: ").append(h.getOrDefault("FILES","?")).append('\n');
        b.append("Toplam boyut: ").append(formatBytes(parseLong(h.get("BYTES")))).append('\n');
        b.append("Wardrobe ID: ").append(h.getOrDefault("HITS","0")).append('\n');
        b.append("Story ID: ").append(h.getOrDefault("STORY_IDS","0")).append('\n');
        b.append("Wardrobe anahtar kelimesi görülen dosya: ").append(h.getOrDefault("WARDROBE_KEYWORD_FILES","0")).append('\n');
        b.append("Okuma hatası: ").append(h.getOrDefault("ERRORS","0")).append('\n');
        b.append("SQLite/DB dosyası: ").append(h.getOrDefault("DB_FILES","0")).append('\n');
        b.append("UnityFS paketleri: ").append(h.getOrDefault("UNITY_BUNDLES","0")).append('\n');
        b.append("UnityFS blokları: ").append(h.getOrDefault("UNITY_BLOCKS","0")).append('\n');
        b.append("UnityFS okunan veri: ").append(formatBytes(parseLong(h.get("UNITY_BYTES")))).append('\n');
        b.append("Sahiplik kanıtı örneği: ").append(h.getOrDefault("EVIDENCE","0")).append('\n');
        b.append("account.json acomp↔apks eşleşmesi: ").append(h.getOrDefault("ACCOUNT_PAIRS","0")).append('\n');
        b.append("Master aday eşleşmesi: ").append(h.getOrDefault("CATALOG_MATCHES","0")).append('\n');
        b.append("Kanıt özeti: ").append(h.getOrDefault("EVIDENCE_SUMMARIES","0")).append('\n\n');

        String ids = h.get("IDS");
        if (ids != null && !ids.isEmpty()) {
            b.append("📌 Bulunan wardrobe kayıtlarından örnekler:\n");
            String[] a = ids.split(",");
            int limit = Math.min(80, a.length);
            for (int i=0; i<limit; i++) b.append(a[i]).append('\n');
            if (a.length > limit) b.append("… ve ").append(a.length-limit).append(" kayıt daha\n");
            if ("1".equals(h.get("TRUNCATED_IDS"))) b.append("⚠️ Sonuç listesi çok büyüdüğü için ayrıntılı liste rapor dosyasına yazıldı.\n");
        } else {
            b.append("⚠️ Henüz doğrudan wardrobe ID bulunamadı.\n");
            b.append("Bu durumda veri başka bir formatta/sıkıştırılmış olabilir; bu tarama sonucu 'kıyafetlerin yok' anlamına gelmez.\n");
        }

        if (!pairLines.isEmpty()) {
            b.append("\n🔗 account.json acomp ↔ apks bağlantılarından örnekler:\n");
            int limit = Math.min(25, pairLines.size());
            for (int i=0; i<limit; i++) b.append("• ").append(pairLines.get(i)).append("\n");
            if (pairLines.size() > limit) b.append("… ve ").append(pairLines.size()-limit).append(" bağlantı daha\n");
            b.append("⚠️ Bu bağlantılar yerel verideki eşleşmedir; tek başına 'sahip' kanıtı değildir.\n");
        }

        if (!evidenceSummaryLines.isEmpty()) {
            b.append("\n🧪 ID kanıt özetleri:\n");
            int limit = Math.min(40, evidenceSummaryLines.size());
            for (int i=0; i<limit; i++) b.append("• ").append(evidenceSummaryLines.get(i)).append("\n");
            if (evidenceSummaryLines.size() > limit) b.append("… ve ").append(evidenceSummaryLines.size()-limit).append(" özet daha\n");
            b.append("⚠️ Bu skorlar yalnızca kanıt sınıflandırmasıdır; otomatik SAHİP/EKSİK kararı değildir.\n");
        }

        if (!matchLines.isEmpty()) {
            b.append("\n🧩 Master ile aday eşleşmeler (ID sırasına göre):\n");
            int limit = Math.min(40, matchLines.size());
            for (int i=0; i<limit; i++) b.append("• ").append(matchLines.get(i)).append("\n");
            if (matchLines.size() > limit) b.append("… ve ").append(matchLines.size()-limit).append(" eşleşme daha\n");
            b.append("⚠️ Bunlar 'aday' eşleşmelerdir; ID→katalog sırası doğrulanmadan eksik listesi sayılmaz.\n");
        }

        if (!fileLines.isEmpty()) {
            b.append("\n📂 ID bulunan dosyalardan örnekler:\n");
            int limit = Math.min(25, fileLines.size());
            for (int i=0; i<limit; i++) {
                String[] p = fileLines.get(i).split("\\|", 4);
                if (p.length >= 4) b.append("• ").append(p[1]).append("\n  ").append(p[3]).append("\n");
            }
        }
        b.append("\n📄 Ayrıntılı tarama raporu otomatik olarak Download/RC_Gardrop_Tarama_Raporu.txt konumuna yazıldı.");
        b.append("\n🔬 EVIDENCE kayıtları, bulunan wardrobe ID'lerinin çevresindeki ham veri bağlamını da içerir.");
        b.append("\nℹ️ Bu sürüm henüz 'eksik kıyafet' hesabı yapmıyor; önce gerçek sahiplik verisinin kaynağını kesinleştiriyoruz.");
        result.setText(b.toString());
    }

    private long parseLong(String s) {
        try { return Long.parseLong(s == null ? "0" : s.trim()); }
        catch (Exception e) { return 0; }
    }

    private String formatBytes(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024*1024) return String.format(Locale.US, "%.1f KB", bytes/1024.0);
        if (bytes < 1024L*1024L*1024L) return String.format(Locale.US, "%.1f MB", bytes/1024.0/1024.0);
        return String.format(Locale.US, "%.2f GB", bytes/1024.0/1024.0/1024.0);
    }

    @Override protected void onDestroy() {
        try {
            if (serviceArgs != null && connection != null)
                Shizuku.unbindUserService(serviceArgs, connection, true);
        } catch (Throwable ignored) {}
        super.onDestroy();
    }
}
